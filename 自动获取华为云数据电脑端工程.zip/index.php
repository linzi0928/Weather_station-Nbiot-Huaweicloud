<?php
     header("content-type:text/html;charset=utf-8");
    $query_time_str=$_GET['time'];
    $ndoe_name=$_GET['node'];
    echo 'GIE气象站数据查询终端'.'<br>';
    echo '查询终止时间：'.$query_time_str.'<br>';
    echo '查询节点名称：'.$ndoe_name.'<br>';
    echo '查询结果：'.'<br>';
  
    $now_date_str=date('Y-m-d', time());
    $time='00:00:00';
    $now_date=strtotime($now_date_str,intval($time));
    $query_time=strtotime($query_time_str,intval($time));
    if(dateBDate($query_time_str,$now_date_str))
    {
        echo '请输入正确的日期（当前日期前）';
    }
    else
    {
        $now_query=$query_time_str;
        $day_before=1;
        while(1)
        {
            $disk="C:\\";###设置配置文件存储路径
            $file = "{$disk}Weather_Data_Archive\\{$ndoe_name}\\{$now_query}.txt";
            if(file_exists($file)){
            ####使用 file_get_contents函数
            $res = file_get_contents($file);
            $res_new = str_replace("\r\n",",",$res);  ##同上.
            echo $res_new; 
            $now_query=date("Y-m-d",strtotime('+'.strval($day_before).' day',strtotime($query_time_str)));
            $day_before=$day_before+1;
               if(dateBDate($now_query,$now_date_str))
                    {
                    break 1;
                    }
            }
            else
            {
                $now_query=date("Y-m-d",strtotime('+'.strval($day_before).' day',strtotime($query_time_str)));
                $day_before=$day_before+1;
                    if(dateBDate($now_query,$now_date_str))
                    {
                    break 1;
                    }
            }
        }
        if(strlen($res_new)<10)
        {
            echo '记录不存在或格式错误，查询示例：'.'<br>'.'http://localhost/?time=2020-03-19&node=node0  即为查询node0 2020年3月18号至今的所有气象数据';
        }
       
    }
    
    function dateBDate($date1, $date2) {
        // 日期1是否大于日期2
         $month1 = date("m", strtotime($date1));
         $month2 = date("m", strtotime($date2));
         $day1 = date("d", strtotime($date1));
         $day2 = date("d", strtotime($date2));
         $year1 = date("Y", strtotime($date1));
         $year2 = date("Y", strtotime($date2));
         $from = intval($year1)*10000+intval($month1)*100+intval($day1);
         $to = intval($year2)*10000+intval($month2)*100+intval($day2);
         if ($from > $to) {
         return true;
         } else {
         return false;
         } 
        } 
?>