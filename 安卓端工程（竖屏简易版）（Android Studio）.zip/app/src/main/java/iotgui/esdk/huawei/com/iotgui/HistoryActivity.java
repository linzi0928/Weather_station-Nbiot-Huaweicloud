package iotgui.esdk.huawei.com.iotgui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static iotgui.esdk.huawei.com.iotgui.MainActivity.history_flag;
import static iotgui.esdk.huawei.com.iotgui.MainActivity.timeZoneTransfer;
import static java.lang.Integer.parseInt;

public class HistoryActivity extends Activity {
    private DatePicker datePicker;
    private TimePicker timePicker;
    public String Picked_time;
    public String Picked_date;
    public static String history_time_stamp;
    private String Query_time_final;
    private String Query_time_ago;
    private Button Button_query;
    private static TextView tx_res;
    public static MainActivity main;
    //MainActivity main=new MainActivity();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        tx_res = (TextView) findViewById(R.id.text_result);
        datePicker = (DatePicker) findViewById(R.id.dp_datetime_picker_date);
        timePicker = (TimePicker) findViewById(R.id.tp_datetime_picker_time);
        Button_query=(Button)findViewById(R.id.bTn_query) ;
        Calendar nowTime = Calendar.getInstance();
        main=new MainActivity();
        Button_query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Query_time_final = timeZoneTransfer(Picked_date+Picked_time, "yyyyMMddHHmm", "+8", "0");
                Query_time_final=Query_time_final.substring(0,8)+"T"+Query_time_final.substring(8,12)+"00"+"Z";
                history_time_stamp=Query_time_final;
                history_flag=1;
                Intent intent=new Intent(HistoryActivity.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
       // nowTime.add(Calendar.HOUR, -8);
        Date ago = nowTime.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy");
        String now_year = format.format(ago);
        format = new SimpleDateFormat("MM");
        String now_month = format.format(ago);
        format = new SimpleDateFormat("dd");
        String now_date = format.format(ago);
        format = new SimpleDateFormat("HHmm");
        String now_time = format.format(ago);
   //     if(history_time_stamp==null) {
            Picked_date = now_year + now_month + now_date;
            Picked_time = now_time;
//        }
//        else
//        {
//            Query_time_ago=history_time_stamp.substring(0,8)+history_time_stamp.substring(9,13);
//            Query_time_ago = timeZoneTransfer(Query_time_ago, "yyyyMMddHHmm", "0", "+8");
//            Picked_date=Query_time_ago.substring(0,8);
//            Picked_time=Query_time_ago.substring(8,12);
//        }

        datePicker.init(parseInt(now_year), parseInt(now_month)-1, parseInt(now_date), new DatePicker.OnDateChangedListener() {
            @Override
             public void onDateChanged(DatePicker view, int year,
                     int monthOfYear, int dayOfMonth) {
                                 // 获取一个日历对象，并初始化为当前选中的时间
                                 Calendar calendar = Calendar.getInstance();
                                 calendar.set(year, monthOfYear, dayOfMonth);
                                SimpleDateFormat format = new SimpleDateFormat(
                                                "yyyyMMdd");
                                Picked_date=format.format(calendar.getTime());
                                Toast.makeText(HistoryActivity.this,
                                                 format.format(calendar.getTime()), Toast.LENGTH_SHORT)
                                         .show();
                            }
        });
        timePicker.setIs24HourView(true);
                 timePicker
                         .setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                     @Override
                     public void onTimeChanged(TimePicker view, int hourOfDay,
                             int minute) {
                                         if(hourOfDay>=10)
                                          Picked_time=String.valueOf(hourOfDay);
                                         else
                                          Picked_time=("0"+String.valueOf(hourOfDay));
                                         if(minute>=10)
                                             Picked_time+=String.valueOf(minute);
                                           else
                                              Picked_time+=("0"+String.valueOf(minute));
                                         Toast.makeText(HistoryActivity.this,
                                                        hourOfDay + "小时" + minute + "分钟",
                                                         Toast.LENGTH_SHORT).show();
                                     }
                 });
    }
}


